<?php

namespace Learn\AdminArea\Controller\Adminhtml\Test;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Learn\AdminArea\Model\ContactFactory;

class Index extends Action
{
    protected $_modelContactFactory;

    public function __construct(
        Context $context,
        ContactFactory $modelContactFactory
    )
    {
        parent::__construct($context);
        $this->_modelContactFactory = $modelContactFactory;
    }

    public function execute()
    {

        $resultPage = $this->_modelContactFactory->create();
        $collection = $resultPage->getCollection(); //Get Collection of module data
        foreach($collection as $item) {
            $item->setName('same');
            $item->save();
            $data= $item->getId();
            $data .= $item->getName();
            $data .= $item->getEmail();
            $data .= $item->getComment();
            echo $data."<br>";
//            echo $data['id']." ".$data['name']." ".$data['email']." ".$data['comment']."<br>";
        }
        exit;
    }
}