<?php

namespace Learn\Test\Block;

use Magento\Framework\View\Element\Template;
use Learn\Test\Model\ProductQuantity;

class StockLeft extends Template
{
    /**
     * @var ProductQuantity
     */
    private $productQuantity;

    public function __construct(
        Template\Context $context,
        ProductQuantity $productQuantity,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->productQuantity = $productQuantity;
    }

    public function getRemainingQuantity($productId)
    {
        return $this->productQuantity->getRemainingQuantity($productId);
    }
}