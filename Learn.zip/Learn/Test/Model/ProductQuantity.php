<?php

namespace Learn\Test\Model;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\CatalogInventory\Api\StockRegistryInterface;

class ProductQuantity
{
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var StockRegistryInterface
     */
    private $stockRegistry;

    public function __construct(
        ProductRepositoryInterface $productRepository,
        StockRegistryInterface $stockRegistry
    ) {
        $this->productRepository = $productRepository;
        $this->stockRegistry = $stockRegistry;
    }

    public function getRemainingQuantity($productId)
    {
        $product = $this->productRepository->getById($productId);
        $stockItem = $this->stockRegistry->getStockItem($productId);
        return $stockItem->getQty();
    }
}
